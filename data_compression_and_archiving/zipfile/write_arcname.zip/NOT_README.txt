The examples for the zipfile module use 
this file and example.zip as data.
